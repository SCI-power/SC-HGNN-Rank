from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .data import CandidateAxisDataset, build_candidate_graph, load_candidate_table, move_dataset_to_device
from .losses import build_pairwise_pairs, combined_rank_loss
from .metrics import ndcg_at_k, safe_pearson, safe_spearman, topk_enrichment
from .model import SCHGNNRank
from .schemas import DEFAULT_SCORE_COLUMNS, LABEL_COLUMN, SOFT_SCORE_COLUMN
from .utils import set_seed


@dataclass
class TrainingResult:
    model: SCHGNNRank
    dataset: CandidateAxisDataset
    metrics: dict[str, float]
    ranked_table: pd.DataFrame


def _split_indices(n: int, seed: int, test_fraction: float = 0.25) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    idx = np.arange(n)
    rng.shuffle(idx)
    n_test = max(1, int(round(n * test_fraction)))
    return idx[n_test:], idx[:n_test]


def _evaluate(model: SCHGNNRank, dataset: CandidateAxisDataset, device: torch.device) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    graph, axis_features = move_dataset_to_device(dataset, device)
    with torch.no_grad():
        logits, score = model(graph, axis_features)
        pred_class = torch.argmax(logits, dim=1).detach().cpu().numpy()
        pred_score = score.detach().cpu().numpy()
    return pred_class, pred_score


def train_model(
    input_table: str | Path | pd.DataFrame,
    score_columns: list[str] | None = None,
    seed: int = 37,
    hidden_dim: int = 96,
    num_layers: int = 2,
    dropout: float = 0.15,
    epochs: int = 80,
    learning_rate: float = 0.0015,
    weight_decay: float = 0.0001,
    patience: int = 20,
    pair_delta: float = 0.05,
    device: str | torch.device | None = None,
) -> TrainingResult:
    set_seed(seed)
    score_columns = score_columns or DEFAULT_SCORE_COLUMNS
    frame = input_table.copy() if isinstance(input_table, pd.DataFrame) else load_candidate_table(input_table)
    dataset = build_candidate_graph(frame, score_columns=score_columns)
    if dataset.labels is None or dataset.soft_scores is None:
        raise ValueError("Training requires label and soft_score columns.")

    device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    graph, axis_features = move_dataset_to_device(dataset, device)
    labels = dataset.labels.to(device)
    soft_scores = dataset.soft_scores.to(device)
    train_idx, val_idx = _split_indices(len(dataset.table), seed)

    model = SCHGNNRank(
        num_node_types=int(dataset.graph["num_node_types"]),
        num_edge_types=int(dataset.graph["num_edge_types"]),
        axis_feature_dim=dataset.axis_features.shape[1],
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    train_frame = dataset.table.iloc[train_idx].copy()
    pair_pos, pair_neg, pair_weight = build_pairwise_pairs(
        train_frame,
        soft_score_column=SOFT_SCORE_COLUMN,
        min_delta=pair_delta,
        seed=seed,
    )
    best_state = None
    best_val = float("inf")
    stale = 0

    train_idx_t = torch.tensor(train_idx, dtype=torch.long, device=device)
    val_idx_t = torch.tensor(val_idx, dtype=torch.long, device=device)

    for _ in range(epochs):
        model.train()
        optimizer.zero_grad()
        logits, score = model(graph, axis_features)
        loss = combined_rank_loss(logits, score, labels, soft_scores, pair_pos, pair_neg, pair_weight, train_idx_t)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
        optimizer.step()

        model.eval()
        with torch.no_grad():
            logits_val, score_val = model(graph, axis_features)
            cls_val = torch.nn.functional.cross_entropy(logits_val[val_idx_t], labels[val_idx_t])
            reg_val = torch.nn.functional.mse_loss(score_val[val_idx_t], soft_scores[val_idx_t])
            val_loss = float((cls_val + reg_val).detach().cpu())

        if val_loss < best_val:
            best_val = val_loss
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    pred_class, pred_score = _evaluate(model, dataset, device)
    y = dataset.soft_scores.detach().cpu().numpy()
    metrics = {
        "spearman": safe_spearman(y, pred_score),
        "pearson": safe_pearson(y, pred_score),
        "mae": float(np.mean(np.abs(y - pred_score))),
        "ndcg_at_5": ndcg_at_k(y, pred_score, k=5),
        "top5_enrichment": topk_enrichment(y, pred_score, k=5, threshold=0.75),
    }

    ranked = dataset.table.copy()
    ranked["predicted_class"] = pred_class
    ranked["predicted_score"] = pred_score
    ranked = ranked.sort_values(["cancer", "predicted_score"], ascending=[True, False]).reset_index(drop=True)
    return TrainingResult(model=model, dataset=dataset, metrics=metrics, ranked_table=ranked)


def save_checkpoint(result: TrainingResult, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "state_dict": result.model.state_dict(),
        "num_node_types": int(result.dataset.graph["num_node_types"]),
        "num_edge_types": int(result.dataset.graph["num_edge_types"]),
        "axis_feature_dim": int(result.dataset.axis_features.shape[1]),
        "score_columns": result.dataset.score_columns,
        "relation_names": result.dataset.relation_names,
    }
    torch.save(payload, path)
