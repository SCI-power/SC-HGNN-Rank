# Reproducibility

## Minimal check

Run:

```bash
python scripts/train_model.py --config configs/example_config.json
python scripts/rank_candidates.py --config configs/example_config.json --checkpoint outputs/example_run/model.pt
python scripts/smoke_test.py
python scripts/reviewer_audit.py
```

The example workflow checks graph construction, model training, ranking and
repository hygiene on a small table.

## Full analysis boundary

The manuscript-scale run depends on public datasets, downloaded pharmacology
resources, spatial transcriptomics sections, single-cell annotations and
external validation tables. Those files are not bundled in this repository.
The scripts here expose the model implementation and reviewer-inspection
workflow without relying on private local file paths.
