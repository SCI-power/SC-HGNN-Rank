from __future__ import annotations

import numpy as np
from scipy.stats import pearsonr, spearmanr


def safe_spearman(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    if len(y_true) < 3 or np.unique(y_true).size < 2 or np.unique(y_pred).size < 2:
        return float("nan")
    return float(spearmanr(y_true, y_pred).correlation)


def safe_pearson(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    if len(y_true) < 3 or np.unique(y_true).size < 2 or np.unique(y_pred).size < 2:
        return float("nan")
    return float(pearsonr(y_true, y_pred).statistic)


def topk_enrichment(y_true: np.ndarray, y_pred: np.ndarray, k: int = 20, threshold: float = 0.75) -> float:
    if len(y_true) == 0:
        return float("nan")
    k = min(k, len(y_true))
    order = np.argsort(-y_pred)[:k]
    observed = float((y_true[order] >= threshold).mean())
    background = float((y_true >= threshold).mean())
    return observed / max(background, 1e-8)


def ndcg_at_k(y_true: np.ndarray, y_pred: np.ndarray, k: int = 20) -> float:
    if len(y_true) == 0:
        return float("nan")
    k = min(k, len(y_true))
    order = np.argsort(-y_pred)[:k]
    gains = np.asarray(y_true, dtype=float)[order]
    discounts = 1.0 / np.log2(np.arange(2, k + 2))
    dcg = float(np.sum(gains * discounts))
    ideal = np.sort(np.asarray(y_true, dtype=float))[::-1][:k]
    idcg = float(np.sum(ideal * discounts))
    return dcg / max(idcg, 1e-8)

