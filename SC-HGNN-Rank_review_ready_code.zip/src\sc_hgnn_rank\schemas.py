ENTITY_COLUMNS = ["cancer", "compound", "target", "regulon", "cell_context"]

DEFAULT_SCORE_COLUMNS = [
    "drug_evidence",
    "single_cell_regulatory",
    "spatial_recurrence",
    "mapping_consistency",
    "ppi_msi",
    "clinical",
    "lincs_cmap",
    "depmap",
    "non_broad_sensitivity",
]

LABEL_COLUMN = "label"
SOFT_SCORE_COLUMN = "soft_score"

RELATION_COLUMNS = {
    "has_cancer": "cancer",
    "has_compound": "compound",
    "has_target": "target",
    "has_regulon": "regulon",
    "has_cell_context": "cell_context",
}

