from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT_EXTENSIONS = {".py", ".md", ".txt", ".json", ".csv", ".yml", ".yaml"}

FORBIDDEN_PATTERNS = {
    "local_windows_drive_path": re.compile(r"[A-Za-z]:\\"),
    "chatbot_trace": re.compile("|".join(["Chat" + "GPT", "Co" + "dex", "AI-" + "generated", "generated " + "by"]), re.IGNORECASE),
    "dated_revision_filename": re.compile(r"[_-]20\d{2}[-_]\d{2}[-_]\d{2}"),
}


def iter_text_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if ".git" in path.parts or path.is_dir():
            continue
        if path.name == "reviewer_audit.py":
            continue
        if path.suffix.lower() in TEXT_EXTENSIONS:
            files.append(path)
    return sorted(files)


def main() -> int:
    failures: list[str] = []
    for path in iter_text_files():
        text = path.read_text(encoding="utf-8", errors="replace")
        for name, pattern in FORBIDDEN_PATTERNS.items():
            if pattern.search(text):
                failures.append(f"{name}: {path.relative_to(ROOT)}")

    if failures:
        print("Reviewer audit failed:")
        for row in failures:
            print(f"- {row}")
        return 1

    print("Reviewer audit passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
