from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from sc_hgnn_rank.predict import rank_candidates
from sc_hgnn_rank.utils import read_json, resolve_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Rank candidate axes with a trained SC-HGNN-Rank checkpoint.")
    parser.add_argument("--config", required=True, help="Path to JSON configuration file.")
    parser.add_argument("--checkpoint", required=True, help="Path to model checkpoint.")
    parser.add_argument("--out", default=None, help="Output CSV path.")
    args = parser.parse_args()

    config = read_json(Path(args.config).resolve())
    input_table = resolve_path(config["input_table"], ROOT)
    checkpoint = resolve_path(args.checkpoint, ROOT)
    out = resolve_path(args.out or "outputs/ranked_candidates.csv", ROOT)
    out.parent.mkdir(parents=True, exist_ok=True)

    model_cfg = config.get("model", {})
    ranked = rank_candidates(
        input_table=input_table,
        checkpoint_path=checkpoint,
        score_columns=config.get("score_columns"),
        hidden_dim=int(model_cfg.get("hidden_dim", 96)),
        num_layers=int(model_cfg.get("num_layers", 2)),
        dropout=float(model_cfg.get("dropout", 0.15)),
    )
    ranked.to_csv(out, index=False)
    print(f"Wrote ranked candidates to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

