# Evidence boundary

The graph ranker and the external evidence review serve different roles.

| Evidence layer | Role |
|---|---|
| Internal graph features | Used by the model to learn candidate-axis priority |
| Pairwise ranking labels | Used during training to improve TopK prioritization |
| Spatial recurrence | Used as a context feature and also reviewed after ranking |
| Direct compound-target evidence | Used for interpretation and claim wording |
| LINCS/CMap, DepMap and drug-response resources | Used as post-ranking support layers |
| Protein or clinical cohort support | Used for interpretation and prioritization |

Post-ranking evidence layers should not be used to retrain the locked model
unless a new training experiment is explicitly declared.

