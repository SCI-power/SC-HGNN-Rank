from __future__ import annotations

from pathlib import Path

import pandas as pd
import torch

from .data import build_candidate_graph, load_candidate_table, move_dataset_to_device
from .model import SCHGNNRank
from .schemas import DEFAULT_SCORE_COLUMNS


def load_model(checkpoint_path: str | Path, hidden_dim: int = 96, num_layers: int = 2, dropout: float = 0.15) -> tuple[SCHGNNRank, list[str]]:
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    model = SCHGNNRank(
        num_node_types=int(checkpoint["num_node_types"]),
        num_edge_types=int(checkpoint["num_edge_types"]),
        axis_feature_dim=int(checkpoint["axis_feature_dim"]),
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout,
    )
    model.load_state_dict(checkpoint["state_dict"])
    return model, list(checkpoint.get("score_columns", DEFAULT_SCORE_COLUMNS))


def rank_candidates(
    input_table: str | Path | pd.DataFrame,
    checkpoint_path: str | Path,
    score_columns: list[str] | None = None,
    hidden_dim: int = 96,
    num_layers: int = 2,
    dropout: float = 0.15,
    device: str | torch.device | None = None,
) -> pd.DataFrame:
    model, checkpoint_score_columns = load_model(checkpoint_path, hidden_dim=hidden_dim, num_layers=num_layers, dropout=dropout)
    score_columns = score_columns or checkpoint_score_columns
    frame = input_table.copy() if isinstance(input_table, pd.DataFrame) else load_candidate_table(input_table)
    dataset = build_candidate_graph(frame, score_columns=score_columns)
    device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    model = model.to(device)
    graph, axis_features = move_dataset_to_device(dataset, device)
    model.eval()
    with torch.no_grad():
        logits, score = model(graph, axis_features)
        pred_class = torch.argmax(logits, dim=1).detach().cpu().numpy()
        pred_score = score.detach().cpu().numpy()

    ranked = dataset.table.copy()
    ranked["predicted_class"] = pred_class
    ranked["predicted_score"] = pred_score
    ranked = ranked.sort_values(["cancer", "predicted_score"], ascending=[True, False]).reset_index(drop=True)
    return ranked

