# Model card

## Intended use

SC-HGNN-Rank ranks candidate compound-target-regulon-cell-context axes for
mechanism discovery and follow-up prioritization.

## Inputs

The model expects a candidate-axis table with entity columns and normalized
evidence scores. Entity columns create a heterogeneous graph. Evidence columns
create axis-level features and edge weights.

## Outputs

The model produces:

- a continuous `predicted_score` in the range 0-1;
- an ordinal `predicted_class`;
- a ranked candidate-axis table.

## Architecture

The model builds a heterogeneous axis graph with entity nodes and relation
types connecting candidate axes to compounds, targets, regulons, cell contexts
and cancer contexts. Relation-aware message passing is combined with an
axis-feature encoder and a fusion head. The training objective includes
classification, score regression and pairwise ranking.

## Limitations

The model is a prioritization model. It does not prove direct compound binding,
drug efficacy or clinical utility. External resources such as perturbation,
dependency or protein-expression databases should be used as post-ranking
evidence layers with source-specific interpretation boundaries.

