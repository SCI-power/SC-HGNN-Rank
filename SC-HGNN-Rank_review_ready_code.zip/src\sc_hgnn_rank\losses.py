from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F


def build_pairwise_pairs(
    frame: pd.DataFrame,
    soft_score_column: str = "soft_score",
    group_column: str = "cancer",
    min_delta: float = 0.05,
    max_pairs: int = 4096,
    seed: int = 37,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rng = np.random.default_rng(seed)
    rows: list[tuple[int, int, float]] = []
    for _, group in frame.groupby(group_column, dropna=False):
        idx = group.index.to_numpy(dtype=int)
        score = pd.to_numeric(group[soft_score_column], errors="coerce").fillna(0.0).to_numpy(dtype=float)
        for i_pos, i in enumerate(idx):
            deltas = score[i_pos] - score
            for j_pos in np.where(deltas >= min_delta)[0]:
                rows.append((int(i), int(idx[j_pos]), float(min(2.0, 0.5 + 4.0 * deltas[j_pos]))))

    if len(rows) > max_pairs:
        weights = np.array([row[2] for row in rows], dtype=float)
        p = weights / weights.sum()
        selected = rng.choice(len(rows), size=max_pairs, replace=False, p=p)
        rows = [rows[i] for i in selected]

    if not rows:
        empty_long = torch.empty(0, dtype=torch.long)
        empty_float = torch.empty(0, dtype=torch.float32)
        return empty_long, empty_long, empty_float

    pos, neg, weight = zip(*rows)
    return (
        torch.tensor(pos, dtype=torch.long),
        torch.tensor(neg, dtype=torch.long),
        torch.tensor(weight, dtype=torch.float32),
    )


def pairwise_rank_loss(
    predicted_score: torch.Tensor,
    pos_idx: torch.Tensor,
    neg_idx: torch.Tensor,
    weight: torch.Tensor,
    temperature: float = 0.08,
) -> torch.Tensor:
    if pos_idx.numel() == 0:
        return predicted_score.sum() * 0.0
    margin = (predicted_score[pos_idx] - predicted_score[neg_idx]) / temperature
    return (F.softplus(-margin) * weight.to(predicted_score.device)).mean()


def combined_rank_loss(
    logits: torch.Tensor,
    predicted_score: torch.Tensor,
    labels: torch.Tensor,
    soft_scores: torch.Tensor,
    pos_idx: torch.Tensor,
    neg_idx: torch.Tensor,
    pair_weight: torch.Tensor,
    train_idx: torch.Tensor | None = None,
) -> torch.Tensor:
    labels = labels.to(logits.device)
    soft_scores = soft_scores.to(predicted_score.device)
    if train_idx is None:
        train_idx = torch.arange(logits.shape[0], device=logits.device)
    else:
        train_idx = train_idx.to(logits.device)
    cls = F.cross_entropy(logits[train_idx], labels[train_idx])
    reg = F.mse_loss(predicted_score[train_idx], soft_scores[train_idx])
    pair = pairwise_rank_loss(predicted_score, pos_idx.to(predicted_score.device), neg_idx.to(predicted_score.device), pair_weight)
    return cls + 0.35 * reg + 0.55 * pair
