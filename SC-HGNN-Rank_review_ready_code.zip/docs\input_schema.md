# Input schema

Each row represents one candidate mechanism axis.

| Column | Required | Description |
|---|---:|---|
| `cancer` | yes | Cancer or disease context |
| `compound` | yes | Representative compound name |
| `target` | yes | Target gene or protein symbol |
| `regulon` | yes | Transcription factor or regulon label |
| `cell_context` | yes | Single-cell or spatial niche label |
| `drug_evidence` | recommended | Compound-target or target-class evidence score |
| `single_cell_regulatory` | recommended | Single-cell regulatory support score |
| `spatial_recurrence` | recommended | Spatial recurrence score across retained sections |
| `mapping_consistency` | recommended | Spatial-mapping method agreement score |
| `ppi_msi` | recommended | PPI/MSI network support score |
| `clinical` | recommended | Prognosis or patient-cohort evidence score |
| `lincs_cmap` | recommended | Perturbation-reversal support score |
| `depmap` | recommended | Cancer dependency support score |
| `non_broad_sensitivity` | recommended | Non-broad-essential target potential score |
| `label` | training only | Ordinal class label: 0, 1 or 2 |
| `soft_score` | training only | Continuous priority label in the range 0-1 |

Missing evidence scores are filled with zero during graph construction. This
means "not available in the input table"; it should not be interpreted as
negative biological evidence.

