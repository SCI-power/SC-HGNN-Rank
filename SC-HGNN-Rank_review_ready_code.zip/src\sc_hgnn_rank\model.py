from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class RelationMessageLayer(nn.Module):
    def __init__(self, hidden_dim: int, num_edge_types: int, dropout: float) -> None:
        super().__init__()
        self.relation = nn.Embedding(num_edge_types, hidden_dim)
        self.message = nn.Linear(hidden_dim * 2, hidden_dim)
        self.update = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(
        self,
        h: torch.Tensor,
        edge_src: torch.Tensor,
        edge_dst: torch.Tensor,
        edge_type: torch.Tensor,
        edge_weight: torch.Tensor,
    ) -> torch.Tensor:
        rel = self.relation(edge_type)
        msg = self.message(torch.cat([h[edge_src], rel], dim=1))
        msg = msg * edge_weight.reshape(-1, 1)
        agg = torch.zeros_like(h)
        agg.index_add_(0, edge_dst, msg)
        denom = torch.zeros((h.shape[0], 1), dtype=h.dtype, device=h.device)
        denom.index_add_(0, edge_dst, edge_weight.reshape(-1, 1).clamp_min(1e-6))
        agg = agg / denom.clamp_min(1.0)
        return h + self.update(agg)


class SCHGNNRank(nn.Module):
    def __init__(
        self,
        num_node_types: int,
        num_edge_types: int,
        axis_feature_dim: int,
        hidden_dim: int = 96,
        num_layers: int = 2,
        dropout: float = 0.15,
        num_classes: int = 3,
    ) -> None:
        super().__init__()
        self.node_type_embedding = nn.Embedding(num_node_types, hidden_dim)
        self.node_feature_projection = nn.Linear(4, hidden_dim)
        self.layers = nn.ModuleList(
            RelationMessageLayer(hidden_dim, num_edge_types, dropout)
            for _ in range(num_layers)
        )
        self.axis_encoder = nn.Sequential(
            nn.Linear(axis_feature_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.fusion_gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 2),
        )
        self.classifier = nn.Linear(hidden_dim, num_classes)
        self.score_head = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(
        self,
        graph: dict[str, torch.Tensor],
        axis_features: torch.Tensor,
        return_attention: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor] | tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        h = self.node_type_embedding(graph["node_type_idx"])
        h = h + self.node_feature_projection(graph["node_struct_features"])
        for layer in self.layers:
            h = layer(
                h,
                graph["edge_src"],
                graph["edge_dst"],
                graph["edge_type_idx"],
                graph["edge_weight"],
            )

        graph_axis = h[graph["axis_node_idx"]]
        feature_axis = self.axis_encoder(axis_features)
        gate = F.softmax(self.fusion_gate(torch.cat([graph_axis, feature_axis], dim=1)), dim=1)
        fused = gate[:, 0:1] * graph_axis + gate[:, 1:2] * feature_axis
        logits = self.classifier(fused)
        score = torch.sigmoid(self.score_head(fused)).squeeze(-1)
        if return_attention:
            return logits, score, gate
        return logits, score

