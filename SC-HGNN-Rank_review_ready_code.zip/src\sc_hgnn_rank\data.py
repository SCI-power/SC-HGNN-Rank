from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .schemas import DEFAULT_SCORE_COLUMNS, ENTITY_COLUMNS, LABEL_COLUMN, RELATION_COLUMNS, SOFT_SCORE_COLUMN


@dataclass
class CandidateAxisDataset:
    table: pd.DataFrame
    graph: dict[str, torch.Tensor]
    axis_features: torch.Tensor
    labels: torch.Tensor | None
    soft_scores: torch.Tensor | None
    score_columns: list[str]
    node_table: pd.DataFrame
    relation_names: list[str]


def load_candidate_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".tsv":
        return pd.read_csv(path, sep="\t")
    return pd.read_csv(path)


def _clean_text(value: object) -> str:
    text = str(value).strip()
    return text if text else "missing"


def _normalized_scores(frame: pd.DataFrame, score_columns: list[str]) -> pd.DataFrame:
    out = frame.copy()
    for col in score_columns:
        if col not in out.columns:
            out[col] = 0.0
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0.0).clip(0.0, 1.0)
    return out


def _interaction_features(scores: pd.DataFrame, score_columns: list[str]) -> pd.DataFrame:
    out = pd.DataFrame(index=scores.index)
    get = lambda col: scores[col] if col in scores.columns else 0.0
    out["spatial_regulon_product"] = get("spatial_recurrence") * get("single_cell_regulatory")
    out["drug_spatial_product"] = get("drug_evidence") * get("spatial_recurrence")
    out["drug_regulon_product"] = get("drug_evidence") * get("single_cell_regulatory")
    out["external_mean"] = scores[[c for c in ["lincs_cmap", "depmap", "clinical"] if c in scores.columns]].mean(axis=1)
    out["evidence_density"] = (scores[score_columns] > 0).mean(axis=1)
    return out.fillna(0.0).clip(0.0, 1.0)


def build_candidate_graph(
    frame: pd.DataFrame,
    score_columns: list[str] | None = None,
) -> CandidateAxisDataset:
    score_columns = score_columns or DEFAULT_SCORE_COLUMNS
    missing = [col for col in ENTITY_COLUMNS if col not in frame.columns]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")

    table = _normalized_scores(frame, score_columns).reset_index(drop=True)
    for col in ENTITY_COLUMNS:
        table[col] = table[col].map(_clean_text)

    node_index: dict[tuple[str, str], int] = {}
    node_rows: list[dict[str, object]] = []

    def add_node(node_type: str, name: str) -> int:
        key = (node_type, name)
        if key not in node_index:
            node_index[key] = len(node_rows)
            node_rows.append({"node_id": len(node_rows), "node_type": node_type, "name": name})
        return node_index[key]

    axis_nodes: list[int] = []
    edge_src: list[int] = []
    edge_dst: list[int] = []
    edge_type: list[int] = []
    edge_weight: list[float] = []
    relation_names: list[str] = []

    def relation_id(name: str) -> int:
        if name not in relation_names:
            relation_names.append(name)
        return relation_names.index(name)

    for row_id, row in table.iterrows():
        axis_label = "|".join(str(row[col]) for col in ENTITY_COLUMNS)
        axis_node = add_node("axis", axis_label)
        axis_nodes.append(axis_node)

        axis_weight = float(np.mean([row[col] for col in score_columns]))
        for rel, col in RELATION_COLUMNS.items():
            node = add_node(col, str(row[col]))
            rid = relation_id(rel)
            rrid = relation_id(f"{rel}_reverse")
            weight = max(axis_weight, float(row.get("drug_evidence", 0.0))) if col == "target" else axis_weight
            edge_src.extend([axis_node, node])
            edge_dst.extend([node, axis_node])
            edge_type.extend([rid, rrid])
            edge_weight.extend([weight, weight])

    node_table = pd.DataFrame(node_rows)
    type_lookup = {name: idx for idx, name in enumerate(sorted(node_table["node_type"].unique()))}
    node_type_idx = torch.tensor([type_lookup[t] for t in node_table["node_type"]], dtype=torch.long)

    degree = np.zeros(len(node_table), dtype=np.float32)
    for s, d in zip(edge_src, edge_dst):
        degree[s] += 1.0
        degree[d] += 1.0
    degree = degree / max(degree.max(), 1.0)
    is_axis = (node_table["node_type"] == "axis").astype(float).to_numpy(dtype=np.float32)
    node_struct_features = torch.tensor(
        np.stack([degree, is_axis, np.ones_like(degree), np.sqrt(degree + 1e-6)], axis=1),
        dtype=torch.float32,
    )

    scores = table[score_columns].astype(float)
    interactions = _interaction_features(scores, score_columns)
    axis_features = torch.tensor(pd.concat([scores, interactions], axis=1).values, dtype=torch.float32)

    labels = None
    if LABEL_COLUMN in table.columns:
        labels = torch.tensor(pd.to_numeric(table[LABEL_COLUMN], errors="coerce").fillna(0).astype(int).values, dtype=torch.long)

    soft_scores = None
    if SOFT_SCORE_COLUMN in table.columns:
        soft_scores = torch.tensor(pd.to_numeric(table[SOFT_SCORE_COLUMN], errors="coerce").fillna(0.0).clip(0, 1).values, dtype=torch.float32)

    graph = {
        "node_type_idx": node_type_idx,
        "node_struct_features": node_struct_features,
        "edge_src": torch.tensor(edge_src, dtype=torch.long),
        "edge_dst": torch.tensor(edge_dst, dtype=torch.long),
        "edge_type_idx": torch.tensor(edge_type, dtype=torch.long),
        "edge_weight": torch.tensor(edge_weight, dtype=torch.float32),
        "axis_node_idx": torch.tensor(axis_nodes, dtype=torch.long),
        "num_node_types": torch.tensor(len(type_lookup), dtype=torch.long),
        "num_edge_types": torch.tensor(len(relation_names), dtype=torch.long),
    }

    return CandidateAxisDataset(
        table=table,
        graph=graph,
        axis_features=axis_features,
        labels=labels,
        soft_scores=soft_scores,
        score_columns=score_columns,
        node_table=node_table,
        relation_names=relation_names,
    )


def move_dataset_to_device(dataset: CandidateAxisDataset, device: torch.device) -> tuple[dict[str, torch.Tensor], torch.Tensor]:
    graph = {key: value.to(device) for key, value in dataset.graph.items()}
    return graph, dataset.axis_features.to(device)
