from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from sc_hgnn_rank.train import save_checkpoint, train_model
from sc_hgnn_rank.utils import read_json, resolve_path, write_json


def main() -> int:
    parser = argparse.ArgumentParser(description="Train SC-HGNN-Rank on a candidate-axis table.")
    parser.add_argument("--config", required=True, help="Path to JSON configuration file.")
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    config = read_json(config_path)
    base = ROOT
    input_table = resolve_path(config["input_table"], base)
    output_dir = resolve_path(config.get("output_dir", "outputs/run"), base)
    output_dir.mkdir(parents=True, exist_ok=True)

    model_cfg = config.get("model", {})
    train_cfg = config.get("training", {})
    result = train_model(
        input_table=input_table,
        score_columns=config.get("score_columns"),
        seed=int(config.get("seed", 37)),
        hidden_dim=int(model_cfg.get("hidden_dim", 96)),
        num_layers=int(model_cfg.get("num_layers", 2)),
        dropout=float(model_cfg.get("dropout", 0.15)),
        epochs=int(train_cfg.get("epochs", 80)),
        learning_rate=float(train_cfg.get("learning_rate", 0.0015)),
        weight_decay=float(train_cfg.get("weight_decay", 0.0001)),
        patience=int(train_cfg.get("patience", 20)),
        pair_delta=float(train_cfg.get("pair_delta", 0.05)),
    )

    save_checkpoint(result, output_dir / "model.pt")
    result.ranked_table.to_csv(output_dir / "ranked_candidates.csv", index=False)
    pd.DataFrame([result.metrics]).to_csv(output_dir / "metrics.csv", index=False)
    write_json({"metrics": result.metrics}, output_dir / "metrics.json")
    print(f"Wrote outputs to {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

