from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from sc_hgnn_rank.train import train_model


def test_smoke_training() -> None:
    result = train_model(ROOT / "examples" / "example_candidate_axes.csv", epochs=2, patience=1)
    assert "predicted_score" in result.ranked_table.columns
    assert len(result.ranked_table) == 12

